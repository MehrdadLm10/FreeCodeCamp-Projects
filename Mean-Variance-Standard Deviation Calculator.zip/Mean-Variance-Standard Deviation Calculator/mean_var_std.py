import numpy as np

def calculate(list):
    
        if len(list) != 9 :
            raise ValueError('List must contain nine numbers.')
        
        np_data = np.array(list).reshape(3,3)

        calculations = {
                    'mean': [np_data.mean(axis=0).tolist(), np_data.mean(axis=1).tolist(), np_data.mean().tolist()],
                    'variance': [np_data.var(axis=0).tolist(), np_data.var(axis=1).tolist(), np_data.var().tolist()],
                    'standard deviation': [np_data.std(axis=0).tolist(), np_data.std(axis=1).tolist(), np_data.std().tolist()],
                    'max': [np_data.max(axis=0).tolist(), np_data.max(axis=1).tolist(), np_data.max().tolist()],
                    'min': [np_data.min(axis=0).tolist(), np_data.min(axis=1).tolist(), np_data.min().tolist()],
                    'sum': [np_data.sum(axis=0).tolist(), np_data.sum(axis=1).tolist(), np_data.sum().tolist()]
                    }
        return calculations
    
list = [2,6,2,8,4,0,1,5,7]
a = calculate(list)
print(a)